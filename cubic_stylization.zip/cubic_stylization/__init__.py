bl_info = {
    "name": "Cubic Stylization",
    "author": "Christopher Mok",
    "version": (1, 1, 0),
    "blender": (2, 93, 0),
    "location": "3D Viewport > Sidebar (N) > Cubify",
    "description": "Cubify meshes (Liu & Jacobson 2019) and ARAP handle deformation. "
                   "Works on triangle and quad meshes; topology and UVs are preserved",
    "category": "Mesh",
}

import os
import site
import subprocess
import sys
import threading
import time

import bpy
import bmesh  # noqa: F401  (kept for users extending the addon)
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader
from mathutils import Euler, Vector
from bpy_extras import view3d_utils

if "solver" in locals():
    import importlib
    importlib.reload(solver)  # noqa: F821
from . import solver

PIN_GROUP = "CubifyPins"


# ================== Mesh helpers

def mesh_kind(me):
    """Classify polygon sizes. Returns (label, tris, quads, ngons)."""
    m = len(me.polygons)
    if m == 0:
        return "No faces", 0, 0, 0
    sizes = np.empty(m, dtype=np.int64)
    me.polygons.foreach_get("loop_total", sizes)
    tris = int(np.count_nonzero(sizes == 3))
    quads = int(np.count_nonzero(sizes == 4))
    ngons = m - tris - quads
    if ngons:
        label = "Mixed mesh (has n-gons)"
    elif tris and quads:
        label = "Mixed mesh (tris + quads)"
    elif quads:
        label = "Quad mesh"
    else:
        label = "Triangle mesh"
    return label, tris, quads, ngons


def read_mesh_arrays(me):
    """Vertex positions and a *virtual* triangulation of the polygons.

    The mesh itself is never modified, so quad/n-gon topology — and with it
    all UV/loop data — is preserved; only vertex positions are solved for.
    """
    n = len(me.vertices)
    V = np.empty(n * 3, dtype=np.float64)
    me.vertices.foreach_get("co", V)
    V = V.reshape(-1, 3)

    me.calc_loop_triangles()
    m = len(me.loop_triangles)
    F = np.empty(m * 3, dtype=np.int64)
    me.loop_triangles.foreach_get("vertices", F)
    return V, F.reshape(-1, 3)


def write_mesh_positions(me, V):
    me.vertices.foreach_set("co", np.asarray(V, dtype=np.float32).ravel())
    me.update()


def get_pin_indices(ob):
    vg = ob.vertex_groups.get(PIN_GROUP)
    if vg is None:
        return []
    gi = vg.index
    return [v.index for v in ob.data.vertices
            if any(g.group == gi for g in v.groups)]


def rotation_part(M):
    """Nearest proper rotation to the 3x3 part of a 4x4 matrix (drops
    scale and shear)."""
    U, _, Vt = np.linalg.svd(np.asarray(M, dtype=np.float64)[:3, :3])
    if np.linalg.det(U @ Vt) < 0:
        U[:, 2] *= -1
    return U @ Vt


def similarity_align(src, dst):
    """Scale s, rotation R, translation t best mapping the points src onto
    dst (same vertex order), so that dst ~ s * src @ R.T + t (Umeyama)."""
    mu_s, mu_d = src.mean(axis=0), dst.mean(axis=0)
    xs, xd = src - mu_s, dst - mu_d
    U, S, Vt = np.linalg.svd(xd.T @ xs)
    d = np.ones(3)
    if np.linalg.det(U @ Vt) < 0:
        d[2] = -1.0
    R = (U * d) @ Vt
    var = float((xs ** 2).sum())
    s = float((S * d).sum()) / var if var > 1e-30 else 1.0
    return s, R, mu_d - s * (R @ mu_s)


# ================== Settings

class CubifySettings(bpy.types.PropertyGroup):
    cubeness: bpy.props.FloatProperty(
        name="Cubeness",
        description="Strength of the L1 cubeness term (lambda). 0 is plain ARAP; "
                    "0.2-1.0 gives increasingly sharp cubes",
        default=0.2, min=0.0, soft_max=5.0, max=20.0, step=1, precision=2)
    orientation: bpy.props.FloatVectorProperty(
        name="Cube Orientation",
        description="Rotation of the target cube axes (in the object's local space)",
        subtype='EULER', default=(0.0, 0.0, 0.0))
    iterations: bpy.props.IntProperty(
        name="Iterations",
        description="Local-global solver iterations",
        default=30, min=1, max=500)
    admm_iterations: bpy.props.IntProperty(
        name="ADMM Iterations",
        description="Maximum inner ADMM iterations per rotation fit "
                    "(stops early on convergence)",
        default=100, min=1, max=300)
    apply_to_copy: bpy.props.BoolProperty(
        name="Apply to Copy",
        description="Cubify a duplicate and keep the original object unchanged",
        default=False)
    stylized_drag: bpy.props.BoolProperty(
        name="Stylized Drag",
        description="Use the current Cubeness during ARAP manipulation, so "
                    "dragging preserves the cubic style (0 = classic ARAP)",
        default=False)
    drag_iterations: bpy.props.IntProperty(
        name="Drag Iterations",
        description="Local-global iterations per mouse move while dragging "
                    "(higher is stiffer/more converged but slower)",
        default=2, min=1, max=20)
    anim_mode: bpy.props.EnumProperty(
        name="Animate By",
        description="What advances from one baked step to the next",
        items=[
            ('LAMBDA', "Cubeness Ramp",
             "Ramp Cubeness from 0 to its current value with a few "
             "warm-started iterations per step — evenly paced, eased "
             "transformation"),
            ('ITER', "Iterations",
             "One solver iteration per step at full Cubeness — the raw "
             "convergence: flat regions snap first, creases sharpen late"),
        ], default='LAMBDA')
    anim_samples: bpy.props.IntProperty(
        name="Steps",
        description="Number of baked steps (one shape key each)",
        default=20, min=2, max=200)
    anim_iters: bpy.props.IntProperty(
        name="Iterations / Step",
        description="Warm-started solver iterations per step (Cubeness Ramp "
                    "mode). Raise it if the final frames look unconverged",
        default=3, min=1, max=50)
    anim_frame_step: bpy.props.IntProperty(
        name="Frame Step",
        description="Timeline frames between baked steps. Style-as-process "
                    "bakes start at the current frame; Cubify Every Frame "
                    "samples the scene frame range at this step",
        default=2, min=1, max=50)
    anim_axes: bpy.props.EnumProperty(
        name="Cube Axes",
        description="What the cube axes are attached to in Cubify Every Frame",
        items=[
            ('OBJECT', "Object",
             "Cube axes turn with the object: a rotating object bakes as a "
             "rotating cubified shape"),
            ('WORLD', "World",
             "Cube axes stay fixed in the world: a rotating object "
             "re-crystallizes against the world axes as it turns"),
        ], default='OBJECT')
    device: bpy.props.EnumProperty(
        name="Device",
        description="Where the solver runs. GPU devices need PyTorch installed "
                    "in Blender's Python (one-click install in the add-on "
                    "preferences)",
        items=[
            ('AUTO', "Auto", "GPU for large meshes when available, else CPU"),
            ('CPU', "CPU", "numpy solver (always available)"),
            ('CUDA', "CUDA GPU", "NVIDIA GPU via PyTorch"),
            ('MPS', "Metal GPU (MPS)", "Apple GPU via PyTorch"),
        ],
        default='AUTO')


# ================== Cubify operator

class OBJECT_OT_cubify(bpy.types.Operator):
    """Apply Cubic Stylization to the selected mesh objects.
    Quad meshes are solved on a virtual triangulation: topology and UVs
    are preserved. Pinned vertices are held in place"""
    bl_idname = "object.cubify_mesh"
    bl_label = "Cubify Mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (context.mode == 'OBJECT' and ob is not None and ob.type == 'MESH')

    def execute(self, context):
        props = context.scene.cubify_settings
        targets = [ob for ob in context.selected_objects if ob.type == 'MESH']
        if not targets and context.active_object and context.active_object.type == 'MESH':
            targets = [context.active_object]
        if not targets:
            self.report({'ERROR'}, "Select at least one mesh object")
            return {'CANCELLED'}

        wm = context.window_manager
        wm.progress_begin(0, 100)
        done = 0
        try:
            for ob in targets:
                ok = self._cubify_object(context, ob, props,
                                         base=done / len(targets),
                                         span=1.0 / len(targets))
                if ok:
                    done += 1
        finally:
            wm.progress_end()

        if done == 0:
            return {'CANCELLED'}
        return {'FINISHED'}

    def _cubify_object(self, context, ob, props, base, span):
        if ob.data.shape_keys is not None:
            self.report({'WARNING'}, f"{ob.name}: skipped (has shape keys)")
            return False
        if len(ob.data.polygons) == 0:
            self.report({'WARNING'}, f"{ob.name}: skipped (no faces)")
            return False

        if props.apply_to_copy:
            dup = ob.copy()
            dup.data = ob.data.copy()
            dup.name = ob.name + "_cubified"
            context.collection.objects.link(dup)
            ob = dup

        me = ob.data
        kind, _, _, _ = mesh_kind(me)
        V, F = read_mesh_arrays(me)
        pins = get_pin_indices(ob)

        A = np.array(Euler(props.orientation, 'XYZ').to_matrix(), dtype=np.float64)

        wm = context.window_manager
        t0 = time.time()
        try:
            stylizer, device, warn = solver.create_stylizer(
                V, F, cubeness=props.cubeness, cube_axes=A, pins=pins,
                device=props.device)
            if warn:
                self.report({'WARNING'}, f"{ob.name}: {warn}")
            V_out = stylizer.run(
                iterations=props.iterations,
                admm_iters=props.admm_iterations,
                on_progress=lambda i, total: wm.progress_update(
                    int(100 * (base + span * i / total))))
        except Exception as exc:
            self.report({'ERROR'}, f"{ob.name}: solver failed ({exc})")
            return False

        if not np.all(np.isfinite(V_out)):
            self.report({'ERROR'}, f"{ob.name}: solver produced invalid positions")
            return False

        write_mesh_positions(me, V_out)

        note = f", {len(pins)} pinned" if pins else ""
        self.report({'INFO'},
                    f"{ob.name} ({kind.lower()}): cubified {len(V)} vertices in "
                    f"{time.time() - t0:.2f}s on {device} "
                    f"(lambda={props.cubeness:.2f}{note})")
        return True


# ================== Style-as-process animation bake

class OBJECT_OT_cubify_bake_anim(bpy.types.Operator):
    """Bake the cubification process as an animation over the timeline:
    one absolute shape key per step, driven by keyframed Evaluation Time.
    The base mesh, topology and UVs are untouched — delete the shape keys
    to get the original back"""
    bl_idname = "object.cubify_bake_animation"
    bl_label = "Bake Animation (Shape Keys)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (context.mode == 'OBJECT' and ob is not None and ob.type == 'MESH')

    def execute(self, context):
        props = context.scene.cubify_settings
        if props.cubeness <= 0.0:
            self.report({'ERROR'}, "Cubeness is 0 — nothing to animate")
            return {'CANCELLED'}
        targets = [ob for ob in context.selected_objects if ob.type == 'MESH']
        if not targets and context.active_object and context.active_object.type == 'MESH':
            targets = [context.active_object]
        if not targets:
            self.report({'ERROR'}, "Select at least one mesh object")
            return {'CANCELLED'}

        wm = context.window_manager
        wm.progress_begin(0, 100)
        done = 0
        try:
            for ob in targets:
                ok = self._bake_object(context, ob, props,
                                       base=done / len(targets),
                                       span=1.0 / len(targets))
                if ok:
                    done += 1
        finally:
            wm.progress_end()

        if done == 0:
            return {'CANCELLED'}
        return {'FINISHED'}

    def _bake_object(self, context, ob, props, base, span):
        me = ob.data
        if me.shape_keys is not None:
            self.report({'WARNING'}, f"{ob.name}: skipped (already has shape keys)")
            return False
        if len(me.polygons) == 0:
            self.report({'WARNING'}, f"{ob.name}: skipped (no faces)")
            return False

        V0, F = read_mesh_arrays(me)
        pins = get_pin_indices(ob)
        A = np.array(Euler(props.orientation, 'XYZ').to_matrix(), dtype=np.float64)

        try:
            stylizer, device, warn = solver.create_stylizer(
                V0, F, cubeness=props.cubeness, cube_axes=A, pins=pins,
                device=props.device)
            if warn:
                self.report({'WARNING'}, f"{ob.name}: {warn}")
        except Exception as exc:
            self.report({'ERROR'}, f"{ob.name}: solver setup failed ({exc})")
            return False

        # Basis = untouched original; every step is its own absolute key.
        # Only shape-key point positions are written: base mesh vertices,
        # topology, UVs and all loop data stay exactly as they are.
        ob.shape_key_add(name="Basis", from_mix=False)
        key = me.shape_keys
        key.use_relative = False

        wm = context.window_manager
        steps = props.anim_samples
        V = V0.copy()
        t0 = time.time()
        for k in range(1, steps + 1):
            if props.anim_mode == 'LAMBDA':
                stylizer.lam = props.cubeness * k / steps
                iters = props.anim_iters
            else:
                iters = 1
            try:
                V = stylizer.solve(V_init=V, iterations=iters,
                                   admm_iters=props.admm_iterations)
            except Exception as exc:
                self.report({'ERROR'}, f"{ob.name}: solver failed at step {k} ({exc})")
                return False
            if not np.all(np.isfinite(V)):
                self.report({'ERROR'}, f"{ob.name}: invalid positions at step {k}")
                return False
            kb = ob.shape_key_add(name=f"Cubify {k:03d}", from_mix=False)
            kb.interpolation = 'KEY_LINEAR'
            kb.data.foreach_set("co", np.asarray(V, dtype=np.float32).ravel())
            wm.progress_update(int(100 * (base + span * k / steps)))

        # Play the key sequence across the timeline: eval_time runs linearly
        # from the Basis key's position to the last key's.
        f0 = context.scene.frame_current
        f1 = f0 + steps * props.anim_frame_step
        key.eval_time = key.key_blocks[0].frame
        key.keyframe_insert(data_path="eval_time", frame=f0)
        key.eval_time = key.key_blocks[-1].frame
        key.keyframe_insert(data_path="eval_time", frame=f1)
        if key.animation_data and key.animation_data.action:
            for fc in key.animation_data.action.fcurves:
                if fc.data_path == "eval_time":
                    for kp in fc.keyframe_points:
                        kp.interpolation = 'LINEAR'

        mode = ("cubeness ramp" if props.anim_mode == 'LAMBDA'
                else "iterations")
        self.report({'INFO'},
                    f"{ob.name}: baked {steps} steps ({mode}) over frames "
                    f"{f0}-{f1} in {time.time() - t0:.2f}s on {device}")
        return True


class OBJECT_OT_cubify_bake_frames(bpy.types.Operator):
    """Cubify the animated mesh at every sampled frame of the scene range
    and bake the results onto a NEW copy object as shape keys over the
    timeline. The copy follows the original's animation (object transforms,
    shape keys, armatures, deforming modifiers — evaluated in world space)
    with each frame re-cubified; the original is untouched"""
    bl_idname = "object.cubify_bake_frames"
    bl_label = "Cubify Every Frame (to Copy)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (context.mode == 'OBJECT' and ob is not None and ob.type == 'MESH')

    def execute(self, context):
        props = context.scene.cubify_settings
        if props.cubeness <= 0.0:
            self.report({'ERROR'}, "Cubeness is 0 — nothing to cubify")
            return {'CANCELLED'}
        ob = context.active_object
        scene = context.scene
        frames = list(range(scene.frame_start, scene.frame_end + 1,
                            props.anim_frame_step))
        if frames[-1] != scene.frame_end:
            frames.append(scene.frame_end)

        frame_restore = scene.frame_current
        wm = context.window_manager
        wm.progress_begin(0, 100)
        new_ob = None
        try:
            # ---- setup from the first sampled frame
            scene.frame_set(frames[0])
            dg = context.evaluated_depsgraph_get()
            ob_eval = ob.evaluated_get(dg)
            me0 = bpy.data.meshes.new_from_object(
                ob_eval, preserve_all_data_layers=True, depsgraph=dg)
            n = len(me0.vertices)
            if n == 0 or len(me0.polygons) == 0:
                bpy.data.meshes.remove(me0)
                self.report({'ERROR'}, f"{ob.name}: evaluated mesh has no geometry")
                return {'CANCELLED'}
            _, F = read_mesh_arrays(me0)

            # pins only translate to the evaluated mesh when no modifier
            # changed the vertex count/order
            pins = []
            if n == len(ob.data.vertices):
                pins = get_pin_indices(ob)
            elif get_pin_indices(ob):
                self.report({'WARNING'},
                            f"{ob.name}: pins ignored (modifiers change the "
                            "vertex count)")

            A = np.array(Euler(props.orientation, 'XYZ').to_matrix(),
                         dtype=np.float64)

            new_ob = bpy.data.objects.new(ob.name + "_cubified_anim", me0)
            context.collection.objects.link(new_ob)
            # world space is baked into the keys; the copy stays at identity
            new_ob.shape_key_add(name="Basis", from_mix=False)
            key = me0.shape_keys
            key.use_relative = False

            # ---- per-frame solve, warm-started from the previous frame
            V_prev = Vw_prev = None
            device = warned = None
            t0 = time.time()
            for i, f in enumerate(frames):
                scene.frame_set(f)
                dg = context.evaluated_depsgraph_get()
                ob_eval = ob.evaluated_get(dg)
                me_ev = ob_eval.data
                if len(me_ev.vertices) != n:
                    raise RuntimeError(
                        f"vertex count changed at frame {f} "
                        f"({len(me_ev.vertices)} vs {n}) — animated "
                        "topology-changing modifiers are not supported")
                V = np.empty(n * 3, dtype=np.float64)
                me_ev.vertices.foreach_get("co", V)
                M = np.array(ob_eval.matrix_world, dtype=np.float64)
                Vw = V.reshape(-1, 3) @ M[:3, :3].T + M[:3, 3]

                A_f = rotation_part(M) @ A if props.anim_axes == 'OBJECT' else A

                # ARAP is invariant under a global rotation of the output,
                # so a warm start left in the previous frame's orientation
                # would keep the result there. Carry it along by however
                # the rest pose moved (object transform, armature, ...).
                V_init = None
                if V_prev is not None:
                    s, R, t = similarity_align(Vw_prev, Vw)
                    V_init = s * V_prev @ R.T + t

                stylizer, device, warn = solver.create_stylizer(
                    Vw, F, cubeness=props.cubeness, cube_axes=A_f, pins=pins,
                    device=props.device)
                if warn and not warned:
                    self.report({'WARNING'}, f"{ob.name}: {warn}")
                    warned = True
                V_out = stylizer.solve(V_init=V_init,
                                       iterations=props.iterations,
                                       admm_iters=props.admm_iterations)
                if not np.all(np.isfinite(V_out)):
                    raise RuntimeError(f"invalid positions at frame {f}")
                V_prev, Vw_prev = V_out, Vw

                kb = new_ob.shape_key_add(name=f"Frame {f:04d}", from_mix=False)
                kb.interpolation = 'KEY_LINEAR'
                kb.data.foreach_set("co", np.asarray(V_out, dtype=np.float32).ravel())
                key.eval_time = kb.frame
                key.keyframe_insert(data_path="eval_time", frame=f)
                wm.progress_update(int(100 * (i + 1) / len(frames)))

            if key.animation_data and key.animation_data.action:
                for fc in key.animation_data.action.fcurves:
                    if fc.data_path == "eval_time":
                        for kp in fc.keyframe_points:
                            kp.interpolation = 'LINEAR'

            self.report({'INFO'},
                        f"{new_ob.name}: {len(frames)} frames "
                        f"({frames[0]}-{frames[-1]}, step {props.anim_frame_step}) "
                        f"in {time.time() - t0:.2f}s on {device}")
            return {'FINISHED'}
        except Exception as exc:
            if new_ob is not None:
                me = new_ob.data
                bpy.data.objects.remove(new_ob)
                bpy.data.meshes.remove(me)
            self.report({'ERROR'}, f"{ob.name}: {exc}")
            return {'CANCELLED'}
        finally:
            scene.frame_set(frame_restore)
            wm.progress_end()


# ================== Pin management

class OBJECT_OT_cubify_pins(bpy.types.Operator):
    """Manage the pinned (handle) vertices stored in the 'CubifyPins'
    vertex group"""
    bl_idname = "object.cubify_pins"
    bl_label = "Cubify Pins"
    bl_options = {'REGISTER', 'UNDO'}

    action: bpy.props.EnumProperty(items=[
        ('SET', "Set From Selection", "Replace pins with the selected vertices"),
        ('ADD', "Add Selection", "Add the selected vertices to the pins"),
        ('CLEAR', "Clear", "Remove all pins"),
    ], default='SET')

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (ob is not None and ob.type == 'MESH'
                and context.mode in {'OBJECT', 'EDIT_MESH'})

    def execute(self, context):
        ob = context.active_object
        prev_mode = ob.mode
        if prev_mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')  # sync edit-mode selection
        try:
            me = ob.data
            if self.action == 'CLEAR':
                vg = ob.vertex_groups.get(PIN_GROUP)
                if vg is not None:
                    ob.vertex_groups.remove(vg)
                self.report({'INFO'}, f"{ob.name}: pins cleared")
                return {'FINISHED'}

            sel = [v.index for v in me.vertices if v.select]
            if not sel:
                self.report({'ERROR'}, "No vertices selected "
                            "(select vertices in Edit Mode first)")
                return {'CANCELLED'}

            vg = ob.vertex_groups.get(PIN_GROUP)
            if vg is None:
                vg = ob.vertex_groups.new(name=PIN_GROUP)
            elif self.action == 'SET':
                vg.remove(list(range(len(me.vertices))))
            vg.add(sel, 1.0, 'REPLACE')
            self.report({'INFO'}, f"{ob.name}: {len(get_pin_indices(ob))} pins")
            return {'FINISHED'}
        finally:
            if prev_mode == 'EDIT':
                bpy.ops.object.mode_set(mode='EDIT')


# ================== Interactive ARAP manipulation

class OBJECT_OT_arap_manipulate(bpy.types.Operator):
    """Interactive ARAP deformation: drag pinned vertices and the mesh
    follows as-rigidly-as-possible. Click near a pin to grab it, drag to
    deform, Enter/Space to confirm, Esc/right-click to cancel"""
    bl_idname = "object.arap_manipulate"
    bl_label = "Start Manipulation"
    bl_options = {'REGISTER', 'UNDO'}

    _PICK_RADIUS_PX = 30.0

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (context.mode == 'OBJECT' and ob is not None and ob.type == 'MESH')

    def invoke(self, context, event):
        ob = context.active_object
        me = ob.data
        if me.shape_keys is not None:
            self.report({'ERROR'}, "Meshes with shape keys are not supported")
            return {'CANCELLED'}
        pins = get_pin_indices(ob)
        if not pins:
            self.report({'ERROR'},
                        "No pins: select vertices and use 'Set From Selection' first")
            return {'CANCELLED'}
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'ERROR'}, "Must be run from a 3D Viewport")
            return {'CANCELLED'}

        props = context.scene.cubify_settings
        V, F = read_mesh_arrays(me)
        lam = props.cubeness if props.stylized_drag else 0.0
        A = np.array(Euler(props.orientation, 'XYZ').to_matrix(), dtype=np.float64)

        try:
            self.solver, device, warn = solver.create_stylizer(
                V, F, cubeness=lam, cube_axes=A, pins=pins,
                device=props.device)
            if warn:
                self.report({'WARNING'}, warn)
        except Exception as exc:
            self.report({'ERROR'}, f"Solver setup failed ({exc})")
            return {'CANCELLED'}

        self.ob = ob
        self.pins = np.asarray(self.solver.pins)          # sorted unique
        self.pin_pos = V[self.pins].copy()                # drag targets
        self.V_orig = V.copy()
        self.V_cur = V.copy()
        self.grab = None                                  # index into self.pins
        self.drag_iters = props.drag_iterations
        self.admm_iters = props.admm_iterations

        self.area = context.area
        self.region = next(r for r in self.area.regions if r.type == 'WINDOW')
        self.rv3d = self.area.spaces.active.region_3d

        try:
            shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        except Exception:
            shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self._shader = shader
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            self._draw_pins, (), 'WINDOW', 'POST_VIEW')

        context.workspace.status_text_set(
            "ARAP Manipulation  |  Left-drag a pin to deform  |  "
            "Enter/Space: confirm  |  Esc/Right-click: cancel")
        context.window_manager.modal_handler_add(self)
        self.area.tag_redraw()
        return {'RUNNING_MODAL'}

    # ---- drawing

    def _draw_pins(self):
        mw = self.ob.matrix_world
        coords = [tuple(mw @ Vector(self.V_cur[p])) for p in self.pins]
        gpu.state.depth_test_set('NONE')
        gpu.state.point_size_set(12.0)
        self._shader.bind()
        self._shader.uniform_float("color", (1.0, 0.15, 0.15, 1.0))
        batch_for_shader(self._shader, 'POINTS', {"pos": coords}).draw(self._shader)
        if self.grab is not None:
            gpu.state.point_size_set(16.0)
            self._shader.uniform_float("color", (0.2, 1.0, 0.3, 1.0))
            g = [tuple(mw @ Vector(self.pin_pos[self.grab]))]
            batch_for_shader(self._shader, 'POINTS', {"pos": g}).draw(self._shader)
        gpu.state.point_size_set(1.0)
        gpu.state.depth_test_set('LESS_EQUAL')

    # ---- interaction helpers

    def _mouse_region_coords(self, event):
        return (event.mouse_x - self.region.x, event.mouse_y - self.region.y)

    def _pick_pin(self, coord):
        """Nearest pin to the 2D mouse position, or None."""
        mw = self.ob.matrix_world
        best, best_d = None, self._PICK_RADIUS_PX
        for k, p in enumerate(self.pins):
            world = mw @ Vector(self.V_cur[p])
            p2d = view3d_utils.location_3d_to_region_2d(self.region, self.rv3d, world)
            if p2d is None:
                continue
            d = (Vector(coord) - p2d).length
            if d < best_d:
                best, best_d = k, d
        return best

    def _drag_update(self, coord):
        mw = self.ob.matrix_world
        cur_world = mw @ Vector(self.pin_pos[self.grab])
        target_world = view3d_utils.region_2d_to_location_3d(
            self.region, self.rv3d, coord, cur_world)
        target_local = mw.inverted() @ target_world
        self.pin_pos[self.grab] = np.array(target_local, dtype=np.float64)

        self.V_cur = self.solver.solve(
            pin_pos=self.pin_pos, V_init=self.V_cur,
            iterations=self.drag_iters, admm_iters=self.admm_iters)
        write_mesh_positions(self.ob.data, self.V_cur)
        self.area.tag_redraw()

    def _exit(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        context.workspace.status_text_set(None)
        self.area.tag_redraw()

    # ---- modal loop

    def modal(self, context, event):
        # let viewport navigation through
        if (event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
                           'TRACKPADPAN', 'TRACKPADZOOM'}
                or event.type.startswith('NUMPAD')):
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                self.grab = self._pick_pin(self._mouse_region_coords(event))
                self.area.tag_redraw()
            elif event.value == 'RELEASE':
                self.grab = None
                self.area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            if self.grab is not None:
                try:
                    self._drag_update(self._mouse_region_coords(event))
                except Exception as exc:
                    self.report({'ERROR'}, f"Solve failed ({exc})")
                    write_mesh_positions(self.ob.data, self.V_orig)
                    self._exit(context)
                    return {'CANCELLED'}
            return {'RUNNING_MODAL'}

        if event.type in {'RET', 'NUMPAD_ENTER', 'SPACE'} and event.value == 'PRESS':
            self._exit(context)
            return {'FINISHED'}

        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            write_mesh_positions(self.ob.data, self.V_orig)
            self._exit(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}


# ================== Panel

class VIEW3D_PT_cubify(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Cubify"
    bl_label = "Cubic Stylization"

    def draw(self, context):
        layout = self.layout
        props = context.scene.cubify_settings
        ob = context.active_object

        if ob is not None and ob.type == 'MESH' and ob.data is not None:
            me = ob.data
            kind, tris, quads, ngons = mesh_kind(me)
            box = layout.box()
            box.label(text=f"{ob.name}: {len(me.vertices)} verts", icon='MESH_DATA')
            box.label(text=f"{kind} ({tris} tris, {quads} quads"
                           + (f", {ngons} n-gons)" if ngons else ")"),
                      icon='MESH_GRID' if quads and not tris else 'MESH_ICOSPHERE')
            if quads or ngons:
                box.label(text="Solved on virtual triangulation;", icon='INFO')
                box.label(text="topology and UVs are preserved")
            n_pins = (len(get_pin_indices(ob)) if len(me.vertices) <= 100000
                      else None)
            if n_pins is None:
                box.label(text=f"Pins: group '{PIN_GROUP}'", icon='PINNED')
            else:
                box.label(text=f"Pins: {n_pins}", icon='PINNED')

        col = layout.column(align=True)
        col.prop(props, "cubeness")
        col.prop(props, "iterations")
        col.prop(props, "admm_iterations")
        layout.prop(props, "device")
        info = solver.torch_device_info_cached()
        if info is not None:
            has_torch, cuda, mps = info
            if props.device in {'CUDA', 'MPS'} and not has_torch:
                layout.label(text="PyTorch not installed: will use CPU",
                             icon='ERROR')
                op = layout.operator("preferences.addon_show",
                                     text="Install in Add-on Preferences",
                                     icon='PREFERENCES')
                op.module = __package__
            elif props.device == 'CUDA' and not cuda:
                layout.label(text="CUDA not available: will use CPU",
                             icon='ERROR')
            elif props.device == 'MPS' and not mps:
                layout.label(text="MPS not available: will use CPU",
                             icon='ERROR')
        layout.prop(props, "orientation")
        layout.prop(props, "apply_to_copy")
        layout.operator(OBJECT_OT_cubify.bl_idname, icon='MESH_CUBE')

        layout.separator()
        box = layout.box()
        box.label(text="Style as Process", icon='SHAPEKEY_DATA')
        row = box.row(align=True)
        row.prop(props, "anim_mode", expand=True)
        col = box.column(align=True)
        col.prop(props, "anim_samples")
        if props.anim_mode == 'LAMBDA':
            col.prop(props, "anim_iters")
        col.prop(props, "anim_frame_step")
        box.operator(OBJECT_OT_cubify_bake_anim.bl_idname, icon='RENDER_ANIMATION')
        box.prop(props, "anim_axes")
        box.operator(OBJECT_OT_cubify_bake_frames.bl_idname, icon='DUPLICATE')

        layout.separator()
        box = layout.box()
        box.label(text="ARAP Manipulation", icon='VIEW_PAN')
        row = box.row(align=True)
        op = row.operator(OBJECT_OT_cubify_pins.bl_idname, text="Set Pins")
        op.action = 'SET'
        op = row.operator(OBJECT_OT_cubify_pins.bl_idname, text="Add")
        op.action = 'ADD'
        op = row.operator(OBJECT_OT_cubify_pins.bl_idname, text="Clear")
        op.action = 'CLEAR'
        box.prop(props, "stylized_drag")
        box.prop(props, "drag_iterations")
        box.operator(OBJECT_OT_arap_manipulate.bl_idname, icon='ORIENTATION_GIMBAL')


# ================== Preferences: one-click PyTorch install

# Install state shared between the worker thread, the watcher timer and the
# preferences UI. Only the worker writes ok/msg/used_user; the UI only reads.
_TORCH_INSTALL = {"thread": None, "ok": None, "msg": "", "used_user": False}


def _torch_pip_command():
    """The pip command for this platform.

    macOS: the default PyPI wheel ships MPS support. Linux: the default
    wheel bundles CUDA. Windows: the default wheel is CPU-only, so the
    CUDA index is needed.
    """
    cmd = [sys.executable, "-m", "pip", "install", "torch"]
    if sys.platform.startswith("win"):
        cmd += ["--index-url", "https://download.pytorch.org/whl/cu126"]
    return cmd


def _user_site_dir():
    try:
        return site.getusersitepackages()
    except Exception:
        return None


def _install_torch_worker():
    """Runs in a background thread so Blender stays responsive during the
    (possibly multi-GB) download. subprocess only — no bpy access here."""
    def run(cmd):
        proc = subprocess.run(cmd, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True)
        print(proc.stdout)  # full pip log to the system console
        return proc

    try:
        run([sys.executable, "-m", "ensurepip", "--upgrade"])  # pip may be absent
        proc = run(_torch_pip_command())
        out = proc.stdout or ""
        if proc.returncode != 0 and ("ermission denied" in out
                                     or "ccess is denied" in out
                                     or "WinError 5" in out):
            # site-packages not writable (e.g. Blender in Program Files):
            # retry in the per-user site, which register() adds to sys.path
            _TORCH_INSTALL["used_user"] = True
            proc = run(_torch_pip_command() + ["--user"])
            out = proc.stdout or ""
        if proc.returncode != 0:
            tail = "\n".join(out.strip().splitlines()[-3:])
            _TORCH_INSTALL["ok"] = False
            _TORCH_INSTALL["msg"] = ("pip failed — see the system console. "
                                     + tail)
        else:
            _TORCH_INSTALL["ok"] = True
    except Exception as exc:
        _TORCH_INSTALL["ok"] = False
        _TORCH_INSTALL["msg"] = f"install failed: {exc}"


def _redraw_preferences():
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'PREFERENCES':
                    area.tag_redraw()
    except Exception:
        pass


def _watch_install():
    """bpy.app.timers callback: poll the worker, then probe the result."""
    thread = _TORCH_INSTALL["thread"]
    if thread is not None and thread.is_alive():
        _redraw_preferences()
        return 0.5
    _TORCH_INSTALL["thread"] = None
    if _TORCH_INSTALL["ok"]:
        if _TORCH_INSTALL["used_user"]:
            usersite = _user_site_dir()
            if usersite and usersite not in sys.path:
                sys.path.append(usersite)
        solver.reset_torch_info()
        has_torch, cuda, mps = solver.torch_device_info()
        if has_torch:
            _TORCH_INSTALL["msg"] = (
                "PyTorch installed — " + _device_summary(cuda, mps))
        else:
            _TORCH_INSTALL["ok"] = False
            _TORCH_INSTALL["msg"] = ("installed, but import failed — "
                                     "restart Blender and check again")
    _redraw_preferences()
    return None


def _device_summary(cuda, mps):
    if cuda:
        return "CUDA GPU available"
    if mps:
        return "Metal GPU (MPS) available"
    return "no GPU device available (CPU-only build or no GPU)"


class CUBIFY_OT_probe_torch(bpy.types.Operator):
    """Check whether PyTorch and a GPU device are available in Blender's
    Python (imports torch, which can take a few seconds)"""
    bl_idname = "cubify.probe_torch"
    bl_label = "Check PyTorch"

    def execute(self, context):
        solver.reset_torch_info()
        has_torch, cuda, mps = solver.torch_device_info()
        if not has_torch:
            _TORCH_INSTALL["msg"] = "PyTorch is not installed"
        else:
            try:
                import torch
                ver = torch.__version__
            except Exception:
                ver = "?"
            _TORCH_INSTALL["msg"] = f"PyTorch {ver} — {_device_summary(cuda, mps)}"
        return {'FINISHED'}


class CUBIFY_OT_install_torch(bpy.types.Operator):
    """Download and install PyTorch into Blender's own Python with pip.
    Runs in the background; Blender stays usable. The GPU build is large
    (macOS ~250 MB, Windows CUDA ~3 GB)"""
    bl_idname = "cubify.install_torch"
    bl_label = "Install PyTorch"

    def execute(self, context):
        if _TORCH_INSTALL["thread"] is not None:
            self.report({'WARNING'}, "Install already running")
            return {'CANCELLED'}
        _TORCH_INSTALL.update(ok=None, msg="Installing… (progress in the "
                              "system console)", used_user=False)
        thread = threading.Thread(target=_install_torch_worker, daemon=True)
        _TORCH_INSTALL["thread"] = thread
        thread.start()
        bpy.app.timers.register(_watch_install, first_interval=0.5)
        self.report({'INFO'}, "PyTorch install started in the background")
        return {'FINISHED'}


class CubifyPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="GPU solver (PyTorch)", icon='SYSTEM')

        installing = _TORCH_INSTALL["thread"] is not None
        info = solver.torch_device_info_cached()
        if installing:
            box.label(text=_TORCH_INSTALL["msg"], icon='SORTTIME')
        elif _TORCH_INSTALL["msg"]:
            icon = 'ERROR' if _TORCH_INSTALL["ok"] is False else 'CHECKMARK'
            box.label(text=_TORCH_INSTALL["msg"], icon=icon)
        elif info is not None:
            has_torch, cuda, mps = info
            if has_torch:
                box.label(text="PyTorch installed — " + _device_summary(cuda, mps),
                          icon='CHECKMARK')
            else:
                box.label(text="PyTorch not installed (CPU solver is used)",
                          icon='INFO')
        else:
            box.label(text="PyTorch not checked yet", icon='QUESTION')

        row = box.row(align=True)
        row.enabled = not installing
        row.operator(CUBIFY_OT_probe_torch.bl_idname, icon='VIEWZOOM')
        row.operator(CUBIFY_OT_install_torch.bl_idname, icon='IMPORT')

        size = "~3 GB (CUDA build)" if sys.platform.startswith("win") else "~250 MB"
        box.label(text=f"Optional — only speeds up meshes over ~20k vertices. "
                       f"Download is {size}.")
        box.label(text="Command: " + " ".join(_torch_pip_command()))


# ================== Registration

_classes = (CubifySettings, OBJECT_OT_cubify, OBJECT_OT_cubify_bake_anim,
            OBJECT_OT_cubify_bake_frames, OBJECT_OT_cubify_pins,
            OBJECT_OT_arap_manipulate, VIEW3D_PT_cubify,
            CUBIFY_OT_probe_torch, CUBIFY_OT_install_torch, CubifyPreferences)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cubify_settings = bpy.props.PointerProperty(type=CubifySettings)
    # a previous session may have pip-installed torch with --user (Blender
    # does not load the user site by default) — make it importable
    usersite = _user_site_dir()
    if (usersite and usersite not in sys.path
            and os.path.isdir(os.path.join(usersite, "torch"))):
        sys.path.append(usersite)


def unregister():
    del bpy.types.Scene.cubify_settings
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
